# The Program would enable user know how much to pay plus tips. The user will provide  figure for the total bill, percentage tip user would like to give & how many people to spilt the bill

print("Welcome to the tip calculator!")

bill = float(input("What is the total bill? $"))

choosePercentage = int(input("What percentage tip would you like to give? 10, 12 or 15? "))

percentageOfTip = (choosePercentage / 100) * bill

totalBill = bill + percentageOfTip

totalPeople = int(input("How many people to spilt the bill? "))

eachPersonPay = round(totalBill / totalPeople, 2)

print(f"Each person should pay: ${eachPersonPay}")

